Yosai uses [GitHub's Releases feature](https://github.com/blog/1547-release-your-software) for its changelogs.

See [the Releases section of our GitHub project](https://github.com/YosaiProject/yosai/releases) for changelogs for each release version of Yosai. 

Release announcement posts on [the official Yosai blog](http://www.example.com) contain summaries of the most noteworthy changes made in each release.

