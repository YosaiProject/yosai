# Respectful Acknowledgement

![respect](img/respect.jpg)

Yosai would not exist without Apache Shiro. Yosai is a port-fork of Apache Shiro, version 2 alpha.  Further, source documentation and sections of this web site's documentation are derived from Apache Shiro sources.

## Naming Yosai
In Japanese, the word Shiro means Castle.  Yosai means fortress.  
Like the names, the projects are similar in meaning, but different.
