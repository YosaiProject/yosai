# Community Discussion

## IRC

Freenode IRC:  #yosai


## Google Groups

Mailing List:  https://groups.google.com/d/forum/yosai
