import pytest
from unittest import mock
import classinjection


def test_inject(monkeypatch):
    dc = type('DumbClass', (object,), {})
    monkeypatch.setattr('classinjection.DumbClass', dc, raising=False)
    newdc = monkeypatch.getattr(classinjection, 'DumbClass')()
    assert newdc.__class__.__name__ == 'DumbClass'
